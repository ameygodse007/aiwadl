connect to shell:
mongo "mongodb+srv://cluster0.ffhnw.mongodb.net/myFirstDatabase" --username gaurav
